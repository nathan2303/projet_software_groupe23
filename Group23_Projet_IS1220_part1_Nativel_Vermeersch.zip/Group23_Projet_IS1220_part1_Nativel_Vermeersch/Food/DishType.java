package Food;

public enum DishType {
	
	Standard,
	Vegetarian,
	GlutenFree,
	VegetarianAndGlutenFree;

}
