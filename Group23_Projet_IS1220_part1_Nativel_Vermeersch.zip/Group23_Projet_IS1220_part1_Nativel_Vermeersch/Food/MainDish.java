package Food;
public class MainDish extends Dish {

	public MainDish(double price, String name, DishType dishType) {
		super(price, name, dishType);
		// TODO Auto-generated constructor stub
	}
	
	
}