package Food;
public class Starter extends Dish {

	public Starter(double price, String name, DishType dishType) {
		super(price, name, dishType);
		// TODO Auto-generated constructor stub
	}
}