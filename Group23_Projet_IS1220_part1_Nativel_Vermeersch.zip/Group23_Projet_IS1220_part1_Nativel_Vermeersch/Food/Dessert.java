package Food;
public class Dessert extends Dish {

	public Dessert(double price, String name, DishType dishType) {
		super(price, name, dishType);
		// TODO Auto-generated constructor stub
	}
	
	
}