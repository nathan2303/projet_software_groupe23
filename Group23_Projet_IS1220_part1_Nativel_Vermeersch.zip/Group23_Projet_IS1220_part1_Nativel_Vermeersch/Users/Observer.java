package Users;
public interface Observer {

  public void update(Restaurant r);

}